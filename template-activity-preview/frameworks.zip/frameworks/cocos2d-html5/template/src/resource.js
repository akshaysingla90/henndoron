var s_HelloWorld = "HelloWorld.jpg";
var s_CloseNormal = "CloseNormal.png";
var s_CloseSelected = "CloseSelected.png";

var g_resources = [
    //image
    s_HelloWorld,
    s_CloseNormal,
    s_CloseSelected

    //plist

    //fnt

    //tmx

    //bgm

    //effect
];